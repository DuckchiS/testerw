function abc(a){
    var c = a + 1;
    return c;
}
var y = abc( abc(7) );
document.write(y); 