// alert("Hello world!");
// confirm("헬로 월드")
// prompt ( "헬로 월드" , 111 );
// document.write("헬로 월드");
// document.write( "<h1>헬로 월드</h1>" );
// console.log( "헬로 월드" );

// var cat = 1;
// var dog = 1 + 3;
// var sum = 4;
// alert(cat);
// alert(dog);
// alert(sum);

// var t = document.getElementById("a");
// t.innerHTML = "고양이";

window.onload = function(){
    var t = document.getElementById("a");
    t.innerHTML = "고양이";
}