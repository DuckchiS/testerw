function addCatAndInputText(){
    var ab = prompt("문자를 입력하시오.");
    document.write(ab + " 고양이");
}
addCatAndInputText();