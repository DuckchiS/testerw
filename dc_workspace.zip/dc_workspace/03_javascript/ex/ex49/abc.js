function cat(){
    this.name = "";
    this.age = 0;
    this.wegiht = 0;
    this.famliy = "";
    this.color = "";
    this.crying = function(){
        document.write("에옹");
        br();
    }
}
new cat();

var kitty = new cat();
kitty.name = "키트";
kitty.age = 4;
kitty.wegiht = 30;
kitty.famliy = "hello";
kitty.color = "white";

var yaongi = new cat();
yaongi.name = "토르";
yaongi.age = 7;
yaongi.wegiht = 9;
yaongi.famliy = "노르웨이 숲";
yaongi.color = "white";

document.write(kitty.name);
br();
document.write(kitty.age);
br();
document.write(kitty.wegiht);
br();
document.write(kitty.color);
br();
document.write(kitty.famliy);
br();

br();br();

document.write(yaongi.name);
br();
document.write(yaongi.age);
br();
document.write(yaongi.wegiht);
br();
document.write(yaongi.color);
br();
document.write(yaongi.famliy);
br();

br();br();

if(kitty.age > yaongi.age){
    document.write("kitty가 형이다.");
}else if(kitty.age < yaongi.age){
    document.write("토르가 형이다.");
}else{
    document.write("둘은 동갑이다.");
}
br();br();

yaongi.crying();
kitty.crying();
br();br();
