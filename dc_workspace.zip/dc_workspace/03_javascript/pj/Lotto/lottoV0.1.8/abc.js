var p = new Array();

p[0] = 6;
p[2] = 9;
p[2] = 12;
p[3] = 18;
p[4] = 24;
p[5] = 43;

var v = new Array();

v[0] = Math.floor(Math.random() * 45) + 1;
document.write(v[0]);
document.write("<br>");
while (true) {
    v[1] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[1]) {
        document.write(v[1]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[2] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[2] && v[1] != v[2]) {
        document.write(v[2]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[3] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[3] && v[1] != v[3] && v[2] != v[3]) {
        document.write(v[3]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[4] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[4] && v[1] != v[4] && v[2] != v[4] && v[3] != v[4]) {
        document.write(v[4]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[5] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[5] && v[1] != v[5] && v[2] != v[5] && v[3] != v[5] && v[4] != v[5]) {
        document.write(v[5]);
        document.write("<br>");
        break;
    }
}

var win = 0;

if (v[0] == p[0]) {
    win = win + 1;
}
if (v[0] == p[1]) {
    win = win + 1;
}
if (v[0] == p[2]) {
    win = win + 1;
}
if (v[0] == p[3]) {
    win = win + 1;
}
if (v[0] == p[4]) {
    win = win + 1;
}
if (v[0] == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v[1] == p[0]) {
    win = win + 1;
}
if (v[1] == p[1]) {
    win = win + 1;
}
if (v[1] == p[2]) {
    win = win + 1;
}
if (v[1] == p[3]) {
    win = win + 1;
}
if (v[1] == p[4]) {
    win = win + 1;
}
if (v[1] == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v[2] == p[0]) {
    win = win + 1;
}
if (v[2] == p[1]) {
    win = win + 1;
}
if (v[2] == p[2]) {
    win = win + 1;
}
if (v[2] == p[3]) {
    win = win + 1;
}
if (v[2] == p[4]) {
    win = win + 1;
}
if (v[2] == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v[3] == p[0]) {
    win = win + 1;
}
if (v[3] == p[1]) {
    win = win + 1;
}
if (v[3] == p[2]) {
    win = win + 1;
}
if (v[3] == p[3]) {
    win = win + 1;
}
if (v[3] == p[4]) {
    win = win + 1;
}
if (v[3] == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v[4] == p[0]) {
    win = win + 1;
}
if (v[4] == p[1]) {
    win = win + 1;
}
if (v[4] == p[2]) {
    win = win + 1;
}
if (v[4] == p[3]) {
    win = win + 1;
}
if (v[4] == p[4]) {
    win = win + 1;
}
if (v[4] == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v[5] == p[0]) {
    win = win + 1;
}
if (v[5] == p[1]) {
    win = win + 1;
}
if (v[5] == p[2]) {
    win = win + 1;
}
if (v[5] == p[3]) {
    win = win + 1;
}
if (v[5] == p[4]) {
    win = win + 1;
}
if (v[5] == p[5]) {
    win = win + 1;
}

document.write("win : " + win);