var p;
function player() {
    p = [];
    while (p.length < 6) {
        var playerNumber = Math.floor(Math.random() * 45) + 1;
        if (!p.includes(playerNumber)) {
            p.push(playerNumber);
        }
    }
    document.write(p + "<br>");
    return p;
}
player();

var lotto;
var bouns
function lottos() {
    lotto = [];
    while (lotto.length < 6) {
        var lottoNumbers = Math.floor(Math.random() * 45) + 1;
        if (!lotto.includes(lottoNumbers)) {
            lotto.push(lottoNumbers);
        }
    }
    document.write(lotto + " ");
    bouns = Math.floor(Math.random() * 45) + 1;
    for (var i = 0; i < 6; i++) {
        if (bouns != lotto[i]) {
            document.write("보너스 번호: " + bouns + "<br>");
            break;
        }
    }
    return lotto;
}
lottos();

var win = 0;
for (var a = 0; a < 6; a++) {
    for (var b = 0; b < 6; b++) {
        if (p[a] == lotto[b]) {
            win = win + 1;
        }
    }
}
document.write("당첨 갯수: " + win + "개<br>");

switch (win) {
    case 0:
    case 1:
    case 2:
        document.write("꽝");
        break;
    case 3:
        document.write("5등");
        break;
    case 4:
        document.write("4등");
        break;
    case 5:
        document.write("3등");
        for(var c = 0; c < 6; c++){
            if(bouns == p[c]){
                document.write("2등");
                break;
            }
        }
        break;
    case 6:
        document.write("1등");
        break;
}
