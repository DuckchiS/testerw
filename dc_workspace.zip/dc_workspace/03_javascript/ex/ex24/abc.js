// var sum = 0;
// for(var i = 1; i <= 10; i++){
//     if(i % 2 == 1){
//         continue;
//     }
//     sum = sum + i;
// }
// alert(sum);

var i = Math.floor(Math.random() * 10) + 1;
for(var s = 1; s <= 10; s++){
    for(var j = 1; j <= 10; j++){
        if(i == s){
            continue;
        } else{
            document.write(s);
        }
    }
    document.write("<br>");
}