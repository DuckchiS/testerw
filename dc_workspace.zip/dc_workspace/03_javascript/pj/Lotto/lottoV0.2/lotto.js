var p;
function player(){
    p = [];
    while(p.length < 6){
        var player = Math.floor(Math.random()*45) + 1;
        if(!p.includes(player)){
            p.push(player);
        }
    }
    document.write("내가 뽑은 번호: " + p + "<br>");
    p.sort();
    return p;
}
player();

var lotto;
function lottos(){
    lotto = [];
    while(lotto.length < 6){
        var lottoNumbers = Math.floor(Math.random()*45) + 1;
        if(!lotto.includes(lottoNumbers)){
            lotto.push(lottoNumbers);
        }
    }
    document.write("인공 로또 번호: " + lotto + " ");
    var bouns = Math.floor(Math.random()*45) + 1;;
    if(bouns != lotto){
        document.write("보너스 번호: " + bouns + "<br>");
    }
    lotto.sort();
    return lotto;
}
lottos();

var win = 0;

for (var i = 0; i <= 5; i++) {
    for (var j = 0; j <= 5; j++) {
        if (p[i] == lotto[j]) {
            win = win + 1;
        }
    }
}

document.write("win : " + win + "<br>");

var str = "";
switch (win) {
    case 0:
    case 1:
    case 2:
        str = "꽝!!! 다음기회에";
        break;
    case 3:
        str = "5등에 당첨되셨습니다.";
        break;
    case 4:
        str = "4등에 당첨되셨습니다.";
        break;
    case 5:
        str = "3등에 당첨되셨습니다.";
        //2등 처리
        for (var i = 0; i < 6; i = i + 1) {
            if (b == p[i]) {    // 보너스 번호가 3등 당첨 유저의 나머지 한번호와 일치하는경우
                // 2등 처리
                str = "2등에 당첨되셨습니다.";
            }
        }
        break;
    case 6:
        str = "1등에 당첨되셨습니다.";
        break;
}
document.write(str);