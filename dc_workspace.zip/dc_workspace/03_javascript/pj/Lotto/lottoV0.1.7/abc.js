var p = new Array();

p[0] = 6;
p[2] = 9;
p[2] = 12;
p[3] = 18;
p[4] = 24;
p[5] = 43;

var v1, v2, v3, v4, v5, v6;

v1 = Math.floor(Math.random() * 45) + 1;
document.write(v1);
document.write("<br>");
while (true) {
    v2 = Math.floor(Math.random() * 45) + 1;
    if (v1 != v2) {
        document.write(v2);
        document.write("<br>");
        break;
    }
}
while (true) {
    v3 = Math.floor(Math.random() * 45) + 1;
    if (v1 != v3 && v2 != v3) {
        document.write(v3);
        document.write("<br>");
        break;
    }
}
while (true) {
    v4 = Math.floor(Math.random() * 45) + 1;
    if (v1 != v4 && v2 != v4 && v3 != v4) {
        document.write(v4);
        document.write("<br>");
        break;
    }
}
while (true) {
    v5 = Math.floor(Math.random() * 45) + 1;
    if (v1 != v5 && v2 != v5 && v3 != v5 && v4 != v5) {
        document.write(v5);
        document.write("<br>");
        break;
    }
}
while (true) {
    v6 = Math.floor(Math.random() * 45) + 1;
    if (v1 != v6 && v2 != v6 && v3 != v6 && v4 != v6 && v5 != v6) {
        document.write(v6);
        document.write("<br>");
        break;
    }
}

var win = 0;

if (v1 == p[0]) {
    win = win + 1;
}
if (v1 == p[1]) {
    win = win + 1;
}
if (v1 == p[2]) {
    win = win + 1;
}
if (v1 == p[3]) {
    win = win + 1;
}
if (v1 == p[4]) {
    win = win + 1;
}
if (v1 == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v2 == p[0]) {
    win = win + 1;
}
if (v2 == p[1]) {
    win = win + 1;
}
if (v2 == p[2]) {
    win = win + 1;
}
if (v2 == p[3]) {
    win = win + 1;
}
if (v2 == p[4]) {
    win = win + 1;
}
if (v2 == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v3 == p[0]) {
    win = win + 1;
}
if (v3 == p[1]) {
    win = win + 1;
}
if (v3 == p[2]) {
    win = win + 1;
}
if (v3 == p[3]) {
    win = win + 1;
}
if (v3 == p[4]) {
    win = win + 1;
}
if (v3 == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v4 == p[0]) {
    win = win + 1;
}
if (v4 == p[1]) {
    win = win + 1;
}
if (v4 == p[2]) {
    win = win + 1;
}
if (v4 == p[3]) {
    win = win + 1;
}
if (v4 == p[4]) {
    win = win + 1;
}
if (v4 == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v5 == p[0]) {
    win = win + 1;
}
if (v5 == p[1]) {
    win = win + 1;
}
if (v5 == p[2]) {
    win = win + 1;
}
if (v5 == p[3]) {
    win = win + 1;
}
if (v5 == p[4]) {
    win = win + 1;
}
if (v5 == p[5]) {
    win = win + 1;
}
//----------------------------------------
if (v6 == p[0]) {
    win = win + 1;
}
if (v6 == p[1]) {
    win = win + 1;
}
if (v6 == p[2]) {
    win = win + 1;
}
if (v6 == p[3]) {
    win = win + 1;
}
if (v6 == p[4]) {
    win = win + 1;
}
if (v6 == p[5]) {
    win = win + 1;
}

document.write("win : " + win);