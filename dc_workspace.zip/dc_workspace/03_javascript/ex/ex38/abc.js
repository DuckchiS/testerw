var p = [];
p[0] = 12;
p[1] = 31;
p[2] = 22;
p[3] = 26;
p[4] = 32;
p[5] = 43;

var lotto = new Array();
lotto[0] = Math.floor(Math.random() * 45) + 1;
document.write(lotto[0]);
document.write("<br>");
while (true) {
    lotto[1] = Math.floor(Math.random() * 45) + 1;
    if (lotto[0] != lotto[1]) {
        document.write(lotto[1]);
        document.write("<br>");
        break;
    }
}
while (true) {
    lotto[2] = Math.floor(Math.random() * 45) + 1;
    if (lotto[0] != lotto[2] && lotto[1] != lotto[2]) {
        document.write(lotto[2]);
        document.write("<br>");
        break;
    }
}
while (true) {
    lotto[3] = Math.floor(Math.random() * 45) + 1;
    if (lotto[0] != lotto[3] && lotto[1] != lotto[3] && lotto[2] != lotto[3]) {
        document.write(lotto[3]);
        document.write("<br>");
        break;
    }
}
while (true) {
    lotto[4] = Math.floor(Math.random() * 45) + 1;
    if (lotto[0] != lotto[4] && lotto[1] != lotto[4] && lotto[2] != lotto[4] && lotto[3] != lotto[4]) {
        document.write(lotto[4]);
        document.write("<br>");
        break;
    }
}
while (true) {
    lotto[5] = Math.floor(Math.random() * 45) + 1;
    if (lotto[0] != lotto[5] && lotto[1] != lotto[5] && lotto[2] != lotto[5] && lotto[3] != lotto[5] && lotto[4] != lotto[5]) {
        document.write(lotto[5]);
        document.write("<br>");
        break;
    }
}
var bouns = Math.floor(Math.random() * 45) + 1;
if (lotto[0] != bouns && lotto[1] != bouns && lotto[2] != bouns && lotto[3] != bouns && lotto[4] != bouns && lotto[5] != bouns) {
    document.write("보너스 번호: " + bouns);
    document.write("<br>");
}
var win = 0;
for (var i = 0; i < 6; i++) {
    for (var j = 0; j < 6; j++) {
        if (p[i] == lotto[j]) {
            win = win + 1;
        }
    }
}
document.write("당첨 갯수: " + win + "개");
document.write("<br>");
switch (win) {
    case 0:
    case 1:
    case 2:
        document.write("꽝");
        break;
    case 3:
        document.write("5");
        break;
    case 4:
        document.write("4");
        break;
    case 5:
        document.write("3");
        break;
        for(var a = 0; a < 6; a++){
            if(bouns == p[a]){
                document.write("2");
            }
        }
        break;
    case 6:
        document.write("1");
        break;
}