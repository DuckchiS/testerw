var player = "";
var computer = "";
var rpcInputText;

window.onload = function(){
    rpcInputText = document.getElementById("rpc_input_text");
}

function rpcInputButtonClick() {
    while (true) {
        player = rpcInputText.value;
        console.log(player);
        if (player == "가위" || player == "바위" || player == "보") {
            break;
        } else {
            alert("다시해");
        }
    }

    computer = Math.floor(Math.random() * 3) + 1;

    if (computer == 1) {
        computer = "가위";
    }
    if (computer == 2) {
        computer = "바위";
    }
    if (computer == 3) {
        computer = "보";
    }

    document.write("이용자: " + player);
    document.write("<br>");
    document.write("컴퓨터 " + computer);
    br();

    var winlose = "";
    switch (player) {
        case "가위":
            if (computer == "가위")
                winlose = "무승부";
            else if (computer == "바위")
                winlose = "패배";
            else if (computer == "보")
                winlose = "승리";
            break;
        case "바위":
            if (computer == "가위")
                winlose = "승리";
            else if (computer == "바위")
                winlose = "무승부";
            else if (computer == "보")
                winlose = "패배";
            break;
        case "보":
            if (computer == "가위")
                winlose = "패배";
            else if (computer == "바위")
                winlose = "승리";
            else if (computer == "보")
                winlose = "무승부";
            break;
    }
    document.write(winlose);
}