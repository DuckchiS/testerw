var p1 = 6;
var p2 = 9;
var p3 = 12;
var p4 = 18;
var p5 = 24;
var p6 = 43;

var v1 = Math.floor(Math.random()*45) + 1;
document.write(v1);
document.write("<br>");
var v2 = Math.floor(Math.random()*45) + 1;
document.write(v2);
document.write("<br>");
var v3 = Math.floor(Math.random()*45) + 1;
document.write(v3);
document.write("<br>");
var v4 = Math.floor(Math.random()*45) + 1;
document.write(v4);
document.write("<br>");
var v5 = Math.floor(Math.random()*45) + 1;
document.write(v5);
document.write("<br>");
var v6 = Math.floor(Math.random()*45) + 1;
document.write(v6);
document.write("<br>");

var win = 0;

if(v1 == p1){
    win = win + 1;
}
if(v1 == p2){
    win = win + 1;
}
if(v1 == p3){
    win = win + 1;
}
if(v1 == p4){
    win = win + 1;
}
if(v1 == p5){
    win = win + 1;
}
if(v1 == p6){
    win = win + 1;
}
//----------------------------------------
if(v2 == p1){
    win = win + 1;
}
if(v2 == p2){
    win = win + 1;
}
if(v2 == p3){
    win = win + 1;
}
if(v2 == p4){
    win = win + 1;
}
if(v2 == p5){
    win = win + 1;
}
if(v2 == p6){
    win = win + 1;
}
//----------------------------------------
if(v3 == p1){
    win = win + 1;
}
if(v3 == p2){
    win = win + 1;
}
if(v3 == p3){
    win = win + 1;
}
if(v3 == p4){
    win = win + 1;
}
if(v3 == p5){
    win = win + 1;
}
if(v3 == p6){
    win = win + 1;
}
//----------------------------------------
if(v4 == p1){
    win = win + 1;
}
if(v4 == p2){
    win = win + 1;
}
if(v4 == p3){
    win = win + 1;
}
if(v4 == p4){
    win = win + 1;
}
if(v4 == p5){
    win = win + 1;
}
if(v4 == p6){
    win = win + 1;
}
//----------------------------------------
if(v5 == p1){
    win = win + 1;
}
if(v5 == p2){
    win = win + 1;
}
if(v5 == p3){
    win = win + 1;
}
if(v5 == p4){
    win = win + 1;
}
if(v5 == p5){
    win = win + 1;
}
if(v5 == p6){
    win = win + 1;
}
//----------------------------------------
if(v6 == p1){
    win = win + 1;
}
if(v6 == p2){
    win = win + 1;
}
if(v6 == p3){
    win = win + 1;
}
if(v6 == p4){
    win = win + 1;
}
if(v6 == p5){
    win = win + 1;
}
if(v6 == p6){
    win = win + 1;
}

document.write("win : " + win);