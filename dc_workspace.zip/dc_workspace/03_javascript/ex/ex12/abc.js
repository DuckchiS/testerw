var s = prompt("값을 입력하세요 : ")
if(s > 100){
    alert("100 보다 큽니다.")
} else {
    alert("100 이하 입니다.")
} 
document.write(s)
