for(var i = 1; i <= 10; i++){
    if(i % 2 == 1){
        document.write(i + "는 홀수 입니다.<br>")
    } else if(i % 2 != 1){
        document.write(i + "는 짝수 입니다.<br>")
    }
}