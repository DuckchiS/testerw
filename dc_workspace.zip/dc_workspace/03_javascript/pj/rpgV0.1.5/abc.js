
var dragon = new Monster("드래곤",100,10);

var elf = new Character();
elf.name = "성모";
elf.hp = 200;
elf.max_hp = 200;
elf.attack = 20;

dragon.info();
elf.info();

hr();
dw("전투시작");
hr();

//todo
// elf.hp = elf.hp - dragon.attack;		// 10 고정 뎀



var elf_attack = r(elf.attack);
var dragon_attack = r(dragon.attack);

hr();
//todo 플레이어 데미지 표시
dw("플레이어 데미지:"+elf_attack);
hr();
//todo 몬스터 데미지 표시
dw("몬스터 데미지:"+dragon_attack);
hr();


elf.hp = elf.hp - dragon_attack;		// 1~10 랜덤 뎀

dragon.hp = dragon.hp - elf_attack;	


dragon.info();
elf.info();

