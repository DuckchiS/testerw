var numbers = new Array();
numbers = [1,2,3,4,5];
var a = numbers[1];
var b = numbers[3];
var sum = 0;
sum = a + b;
alert(sum);