//클래스 생성
function Cat(){
    this.name = "";
    this.age = 0;
    this.wegiht = 0;
    this.famliy = "";
    this.color = "";
}
//클래스 객체 생성
new Cat();
//변수 선언을 하고 클래스 객체에 생성문 넣기(대입하기)
var kitty = new Cat();
//클래스형 변수가 가진 변수들에 데이터 넣기
kitty.name = "kitty";
kitty.age = 30;
kitty.wegiht = 30;
kitty.famliy = "hello";
kitty.color = "white";
document.write(kitty.name);