var p = new Array();

p[0] = 6;
p[2] = 9;
p[2] = 12;
p[3] = 18;
p[4] = 24;
p[5] = 43;

var v = new Array();

v[0] = Math.floor(Math.random() * 45) + 1;
document.write(v[0]);
document.write("<br>");
while (true) {
    v[1] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[1]) {
        document.write(v[1]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[2] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[2] && v[1] != v[2]) {
        document.write(v[2]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[3] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[3] && v[1] != v[3] && v[2] != v[3]) {
        document.write(v[3]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[4] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[4] && v[1] != v[4] && v[2] != v[4] && v[3] != v[4]) {
        document.write(v[4]);
        document.write("<br>");
        break;
    }
}
while (true) {
    v[5] = Math.floor(Math.random() * 45) + 1;
    if (v[0] != v[5] && v[1] != v[5] && v[2] != v[5] && v[3] != v[5] && v[4] != v[5]) {
        document.write(v[5]);
        document.write("<br>");
        break;
    }
}
var b = 0;
while(true){
    b = Math.floor(Math.random() * 45) + 1;
    if(b != v[5] && b != v[5] && b != v[5] && b != v[5] && b != v[5]){
        document.write("보너스 번호: " + b);
        document.write("<br>");
        break;
    } 
}

var win = 0;

for(var i = 0; i < 5; i++){
    for(var j = 0; j < 5; j++){
        if(p[i] == v[j]){
            win = win + 1;
        }
    }
}

document.write("win : " + win);

///////////////////////////////////////////////////////
var str = "";
switch(win){
    case 0:
    case 1:
    case 2:
        str = "꽝!!! 다음기회에";
        break;
    case 3:
        str = "4등에 당첨되셨습니다.";
        break;
    case 4:
        str = "3등에 당첨되셨습니다.";
        break;
    case 5:
        str = "2등에 당첨되셨습니다.";
        break;
    case 6:
        str = "1등에 당첨되셨습니다.";
        break;        
}
document.write(str);
