// - 전투 무한 루프 처리 : 전투 시 플레이어나 적의 현재 체력이 0 이하로 될 때까지(죽을때 까지) 전투 반복 처리
var t;
var str = "";
var dragon;
var elf;

window.onload = function () {

	t = document.getElementById("abc");

	dragon = new Monster("드래곤", 2000, 20, 3000, 1500);

	elf = new Character();
	elf.name = "성모";
	elf.hp = 200;
	elf.max_hp = 200;
	elf.attack = 20;
	elf.exp = 0;
	elf.gold = 0;
	elf.next_exp = 150;

	elf.info();
	dragon.info();

	hr();
	dw("전투시작");
	hr();

	while (true) {
		proc_battle();

		if (elf.hp <= 0 || dragon.hp <= 0) {
			break;
		}
	}

	dw("전투종료"); br();
	if (dragon.hp <= 0) {
		dw("불쌍한 " + dragon.name + ", " + elf.name + "에게 경험치 " + dragon.exp + " 을 주고 죽었습니다.");
		elf.exp = elf.exp + dragon.exp;
		dw(dragon.gold + " 골드를 얻었습니다.");
		elf.gold = elf.gold + dragon.gold;
		hr(); hr();
		elf.info();
	}
	if (elf.hp <= 0) {
		dw("gameOver")
	}
	br();

	hr(); hr();
}

function proc_battle() {
	var elf_attack = r(elf.attack);
	var dragon_attack = r(dragon.attack);

	hr();
	dw("플레이어 데미지:" + elf_attack);
	hr();
	dw("몬스터 데미지:" + dragon_attack);
	hr();

	elf.hp = elf.hp - dragon_attack;		// 1~10 랜덤 뎀
	dragon.hp = dragon.hp - elf_attack;

	elf.info();
	dragon.info();
}
