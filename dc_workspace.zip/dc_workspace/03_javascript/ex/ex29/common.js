function br(){
    document.write("<br>");
}
function dw(str){
    document.write(str);
}