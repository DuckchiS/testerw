function lottos() {
    var lotto = new Array();
    var bouns = Math.floor(Math.random() * 45) + 1;
    while(lotto.length < 6){
        var lottoNumbers = Math.floor(Math.random() * 45) + 1;
        if(!lotto.includes(lottoNumbers)){
            lotto.push(lottoNumbers);
        }
    }
    document.write("로또 번호: " + lotto);
    if(lotto != bouns){
        document.write("보너스: " + bouns);
    }
    return lotto;
}
var ab = lottos();
//-------------------------------------------------------------------------------------------
function generateLottoNumbers() {
    const lottoNumbers = [];
    
    while (lottoNumbers.length < 6) {
        const randomNumber = Math.floor(Math.random() * 45) + 1;

        // 중복된 번호 방지
        if (!lottoNumbers.includes(randomNumber)) {
            lottoNumbers.push(randomNumber);
        }
    }

    lottoNumbers.sort((a, b) => a - b); // 번호 정렬
    return lottoNumbers;
}

// 예시: 생성된 로또 번호 출력
const result = generateLottoNumbers();
console.log("로또 번호: " + result.join(", "));