function abc(a){
    var c = a + 1;
    return c;
}
var y = abc(100);
document.write(y); 