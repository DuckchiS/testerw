for(var i = 0; i < 5; i++){
    document.write("고양이<hr>")
}