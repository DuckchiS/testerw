document.write("<img src ='dice" + (Math.floor(Math.random()*6)+1) + ".jpeg'")

