for(var i = 0; i < 10; i++){
    for(var k = 0; k <= i - 1; k++){
        document.write("&nbsp;")
    }
    for(var j = 9; j >= i; j--){
        document.write("*") * j;
    }
    document.write("<br>");
}