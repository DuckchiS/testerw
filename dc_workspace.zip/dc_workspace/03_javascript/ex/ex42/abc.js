function abc(){
    var a = 100;
    return a;
}
function def(){
    var d = 200;
    return d;
}
function add(a, b){
    var sum = a + b;
    return sum;
}
var y = add(abc(), def());
document.write(y);