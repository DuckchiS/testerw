var player = prompt("가위, 바위, 보");
var computer = Math.floor(Math.random() * 3) + 1;

if (computer == 1) {
    computer = "가위";
}
if (computer == 2) {
    computer = "바위";
}
if (computer == 3) {
    computer = "보";
}

document.write("이용자: " + player);
document.write("<br>");
document.write("컴퓨터 " + computer);
document.write("<br>");

var winlose = "";
switch (player) {
    case "가위":
        if (computer == "가위")
            winlose = "무승부";
        else if (computer == "바위")
            winlose = "패배";
        else if (computer == "보")
            winlose = "승리";
        break;
    case "바위":
        if (computer == "가위")
            winlose = "승리";
        else if (computer == "바위")
            winlose = "무승부";
        else if (computer == "보")
            winlose = "패배";
        break;
    case "보":
        if (computer == "가위")
            winlose = "패배";
        else if (computer == "바위")
            winlose = "승리";
        else if (computer == "보")
            winlose = "무승부";
        break;
}
document.write(winlose);