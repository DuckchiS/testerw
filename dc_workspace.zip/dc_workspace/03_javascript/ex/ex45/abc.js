function cat(){
    this.name = "";
    this.age = 0;
    this.wegiht = 0;
    this.famliy = "";
    this.color = "";
}