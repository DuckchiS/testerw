for(var j = 0; j < 5; j++){
    document.write("<img src='cat.jpg'>")
}