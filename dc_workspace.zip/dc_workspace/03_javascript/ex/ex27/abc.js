//논리연산자 &&, ||
//a가 b보다 큼 그리고 c가 d보다 작음 또는 e가 100과 같음 f가 100이 아님
//1.위의 조건을 if 조건문으로 만들기
//2.위 조건을 다 만족(ok, 참, true) 시키게끔 a,b,c,d,e,f값을 적절하게 주기
//3.조건을 만족하면 고양이 문자열 출력하기
var a = 124;
var b = 122;
var c = 111;
var d = 222;
var e = 100;
var f = 100;
if ((a > b && c < d) || (e == 100 && f != 100)) {
    document.write("고양이");
    br();
    document.write("cat");
}


