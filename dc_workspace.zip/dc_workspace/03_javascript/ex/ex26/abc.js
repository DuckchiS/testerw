function cat() {
    var cat_name = "웨이";
    var cat_age = "3살";
    var cat_breed = "노르웨이숲";
    var total = cat_name + cat_age + cat_breed;
    alert(total)
}
cat();