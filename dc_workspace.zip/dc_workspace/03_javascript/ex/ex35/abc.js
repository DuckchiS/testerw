var numbers = new Array();
numbers = ["개", "고양이", "너굴맨"];
var ab = numbers[1] + numbers[0];
alert(ab);