function cat(){
    this.name = "";
    this.age = 0;
    this.wegiht = 0;
    this.famliy = "";
    this.color = "";
}
new cat();
var kitty = new cat();
kitty.name = "kitty";
kitty.age = 30;
kitty.wegiht = 30;
kitty.famliy = "hello";
kitty.color = "white";
document.write(kitty.name);
br();
document.write(kitty.age);
br();
document.write(kitty.wegiht);
br();
document.write(kitty.name);
br();
document.write(kitty.famliy);
br();