for(var i = 0; i < 10; i++){
    for(var k = 10; k >= i - 1; k--){
        document.write("&nbsp;")
    }
    for(var j = 0; j <= i; j++){
        document.write("*") * j;
    }
    document.write("<br>");
}