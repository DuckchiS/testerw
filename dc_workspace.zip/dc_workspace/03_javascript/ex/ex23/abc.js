// var sum = 0;
// for(var i = 1; i <= 10; i++){
//     sum = sum + i;
//     if(sum > 30) 
//         break;
// }
// alert(sum);

var i = Math.floor(Math.random() * 10) + 1;
for(var s = 1; s <= 10; s++){
    if(i == s){
        break;
    } else{
        document.write(s);
    }
}