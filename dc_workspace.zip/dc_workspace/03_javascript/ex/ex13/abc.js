var s = prompt("값을 입력하세요 : ")
if(s > 100){
    alert("100 보다 큽니다.")
} else if(s < 100){
    alert("100 보다 작습니다.")
} else {
    alert("100 입니다.")
}
document.write(s)