var player = "";
var computer = "";

var rpcInputText;
var rpcResultScreen;

var resultString = "";

window.onload = function(){
    rpcInputText = document.getElementById("rpc_input_text");
    rpcResultScreen = document.getElementById("rpc_result_screen");
}

function rpcInputButtonClick() {
    while (true) {
        player = rpcInputText.value;
        console.log(player);
        if (player == "가위" || player == "바위" || player == "보") {
            break;
        } else {
            alert("다시해");
        }
    }

    computer = Math.floor(Math.random() * 3) + 1;

    if (computer == 1) {
        computer = "가위";
    }
    if (computer == 2) {
        computer = "바위";
    }
    if (computer == 3) {
        computer = "보";
    }

     // dw("유저:"+userRpc);
    // resultString += "유저:"+userRpc;
    resultString = "유저:" + player; // * 주의 * 다시 게임을 할 경우 이 명령줄로 인해 기존 누적된 내용이 초기화가 됨.
    
    // br();
    // resultString += "\n";
    resultString = resultString + "\n";
        
    // dw("컴:"+comRpc);    
    // resultString += "컴:"+comRpc;
    resultString = resultString + "컴:" + computer;

    // br();
    resultString += "\n";

    var winlose = "";
    switch (player) {
        case "가위":
            if (computer == "가위")
                winlose = "무승부";
            else if (computer == "바위")
                winlose = "패배";
            else if (computer == "보")
                winlose = "승리";
            break;
        case "바위":
            if (computer == "가위")
                winlose = "승리";
            else if (computer == "바위")
                winlose = "무승부";
            else if (computer == "보")
                winlose = "패배";
            break;
        case "보":
            if (computer == "가위")
                winlose = "패배";
            else if (computer == "바위")
                winlose = "승리";
            else if (computer == "보")
                winlose = "무승부";
            break;
    }
    // dw(winDrawLose);    
    // resultString += "결과: " + winDrawLose;
    resultString = resultString + "결과: " + winlose;

    // 결과 출력
    rpcResultScreen.value = resultString;
}