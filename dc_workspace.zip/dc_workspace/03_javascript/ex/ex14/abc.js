var s = prompt("값을 입력하세요 : ")
switch(s){
    case "1":
        alert("1 입니다.")
        break;
    case "2":
        alert("2 입니다.")
        break;
    case "3":
        alert("3 입니다.")
        break;
    default:
        alert("1,2,3이 아닙니다.")
}