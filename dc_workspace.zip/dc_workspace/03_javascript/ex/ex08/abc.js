var random;
random = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.
console.log(random)
switch(random){
    case 1:
        document.write("<img src='dice1.jpeg'>")
        break;
    case 2:
        document.write("<img src='dice2.jpeg'>")
        break;
    case 3:
        document.write("<img src='dice3.jpeg'>")
        break;
    case 4:
        document.write("<img src='dice4.jpeg'>")
        break;
    case 5:
        document.write("<img src='dice5.jpeg'>")
        break;
    case 6:
        document.write("<img src='dice6.jpeg'>")
        break;
}

