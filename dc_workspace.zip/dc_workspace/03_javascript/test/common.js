function br(){
    document.write("cart");
    document.write("cart");
    document.write("cart");
    document.write("cart");
    document.write("cart");
}
for(var y = 0; y < 5; y++){
    br();
}